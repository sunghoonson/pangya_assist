# Pangya plugin / patch source archive

이 압축은 `plugins fetch.zip` 결과물을 다시 만들기 위한 **복원용 C++/BAT 소스 묶음**입니다.

중요:
- 이 소스는 남아 있는 DLL 문자열, ProjectG127.exe hook 위치, GUI가 읽는 live JSON 계약을 기준으로 다시 정리한 복원판입니다.
- 예전에 채팅에서 제공했던 원문과 줄 단위로 완전히 같은 파일이라는 보장은 없습니다.
- 목적은 동일한 DLL 이름과 JSON 파일명을 다시 빌드/보관할 수 있게 하는 것입니다.
- 반드시 32-bit/x86 MSVC 환경에서 빌드하세요. 예: Visual Studio의 `x86 Native Tools Command Prompt`.

## 폴더

- `common/`
  - 공통 hook/write/json 유틸 헤더
- `pangya_plugin_loader/`
  - `pangya_plugins.txt`를 읽어 플러그인 DLL들을 LoadLibrary 하는 로더 DLL 소스
- `pangya_distance_height_logger/`
  - `pangya_distance_height_live.json`
- `pangya_ground_logger/`
  - `pangya_ground_live.json`
- `pangya_club_logger/`
  - `pangya_club_live.json`
- `pangya_wind_logger/`
  - `pangya_wind_live.json`
- `pangya_slope_logger/`
  - `pangya_slope_live.json`
- `pangya_spin_curve_live_logger/`
  - `pangya_spin_curve_live.json`
- `pangya_lateral_offset_logger/`
  - `pangya_lateral_offset_live.json`
- `exe_patch_sources/`
  - `GameServer-01.exe`/원본 계열 패치용 Python
  - `ProjectG127.exe` 1인 abort skip 패치용 Python
- `reference_current_outputs/`
  - 현재 남아 있던 `plugins fetch.zip` 원본 결과물
- `runtime_files/`
  - 현재 샘플 live JSON

## 전체 빌드

VS x86 개발자 명령 프롬프트에서:

```bat
cd /d C:\path\to\pangya_reconstructed_plugin_sources
build_all_plugins.bat
```

각 DLL은 각 플러그인 폴더의 `dist\*.dll`로 생성됩니다.

## 개별 빌드 예

```bat
cd /d C:\path\to\pangya_reconstructed_plugin_sources\pangya_wind_logger
build.bat
```

## 로더용 pangya_plugins.txt 예

`pangya_plugin_loader.dll`과 같은 폴더에 아래 파일을 두면 로더가 순서대로 DLL을 로드합니다.

```txt
pangya_distance_height_logger.dll
pangya_ground_logger.dll
pangya_club_logger.dll
pangya_wind_logger.dll
pangya_slope_logger.dll
pangya_spin_curve_live_logger.dll
pangya_lateral_offset_logger.dll
```

## EXE 패치

`exe_patch_sources` 안의 Python 파일은 기존에 성공/실험했던 패치 소스입니다.

```bat
python patch_projectg_skip_single_player_abort_test.py ProjectG127.exe
python patch_gameserver_build_all_clean_from_original.py GameServer-02.exe
```

