#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

static std::string dll_dir(HMODULE self) {
    char path[MAX_PATH] = {0};
    GetModuleFileNameA(self, path, MAX_PATH);
    std::string s(path);
    size_t p = s.find_last_of("\\/");
    if (p != std::string::npos) s.resize(p);
    return s;
}

static void append_log(const std::string& base, const char* fmt, ...) {
    std::string path = base + "\\pangya_plugin_loader.log";
    FILE* fp = nullptr;
    fopen_s(&fp, path.c_str(), "ab");
    if (!fp) return;
    char buf[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf_s(buf, sizeof(buf), _TRUNCATE, fmt, ap);
    va_end(ap);
    fprintf(fp, "%s\r\n", buf);
    fclose(fp);
}

static std::string trim(std::string s) {
    while (!s.empty() && (s.back()=='\r'||s.back()=='\n'||s.back()==' '||s.back()=='\t')) s.pop_back();
    size_t i=0; while (i<s.size() && (s[i]==' '||s[i]=='\t')) ++i;
    return s.substr(i);
}

DWORD WINAPI LoaderThread(LPVOID p) {
    HMODULE self = (HMODULE)p;
    std::string base = dll_dir(self);
    append_log(base, "========== pangya_plugin_loader start ==========");
    append_log(base, "base_dir=%s", base.c_str());

    std::vector<std::string> names;
    std::ifstream f((base + "\\pangya_plugins.txt").c_str());
    if (f.good()) {
        std::string line;
        while (std::getline(f, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') continue;
            names.push_back(line);
        }
        append_log(base, "mode=pangya_plugins.txt count=%u", (unsigned)names.size());
    } else {
        // pangya_plugins.txt가 없으면 같은 폴더의 대표 플러그인명을 시도한다.
        const char* defaults[] = {
            "pangya_distance_height_logger.dll",
            "pangya_ground_logger.dll",
            "pangya_club_logger.dll",
            "pangya_wind_logger.dll",
            "pangya_slope_logger.dll",
            "pangya_spin_curve_live_logger.dll",
            "pangya_lateral_offset_logger.dll",
        };
        for (auto n: defaults) names.push_back(n);
        append_log(base, "mode=default count=%u", (unsigned)names.size());
    }

    for (const auto& name: names) {
        std::string full = name;
        if (full.find(':') == std::string::npos && full.find('\\') == std::string::npos && full.find('/') == std::string::npos)
            full = base + "\\" + full;
        HMODULE h = LoadLibraryA(full.c_str());
        if (h) append_log(base, "LOADED %s hmodule=0x%p", full.c_str(), h);
        else append_log(base, "FAILED %s error=%lu", full.c_str(), GetLastError());
    }
    append_log(base, "========== pangya_plugin_loader done ==========");
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        HANDLE h = CreateThread(NULL, 0, LoaderThread, hModule, 0, NULL);
        if (h) CloseHandle(h);
    }
    return TRUE;
}
