#include "pangya_plugin_common.h"

static volatile LONG g_height_ok=0, g_distance_ok=0, g_distance_live_ok=0;
static volatile LONG g_height_count=0, g_distance_count=0, g_distance_live_count=0;
static DWORD g_ret_height=0, g_ret_distance=0, g_ret_distance_live=0;
static DWORD g_height_base=0, g_distance_base=0, g_distance_live_base=0;
static float g_height=0.0f, g_distance=0.0f, g_distance_live=0.0f;

extern "C" __declspec(noinline) void __stdcall CaptureHeight(DWORD esi_value) {
    g_height_base = esi_value;
    float v=0.0f;
    if (pangya_read_value<float>(esi_value + 0x34, v)) {
        g_height = v;
        InterlockedIncrement((LONG*)&g_height_count);
    }
}
extern "C" __declspec(noinline) void __stdcall CaptureDistanceFinal(DWORD esi_value) {
    g_distance_base = esi_value;
    float v=0.0f;
    if (pangya_read_value<float>(esi_value + 0x2C, v)) {
        g_distance = v;
        InterlockedIncrement((LONG*)&g_distance_count);
    }
}
extern "C" __declspec(noinline) void __stdcall CaptureDistanceLive(DWORD edi_value) {
    g_distance_live_base = edi_value;
    float v=0.0f;
    if (pangya_read_value<float>(edi_value + 0x4C, v)) {
        g_distance_live = v;
        InterlockedIncrement((LONG*)&g_distance_live_count);
    }
}

__declspec(naked) void HookHeight() {
    __asm {
        fld dword ptr [esi+34h]
        fstp dword ptr [ebp-38h]
        pushfd
        pushad
        push esi
        call CaptureHeight
        popad
        popfd
        jmp dword ptr [g_ret_height]
    }
}
__declspec(naked) void HookDistanceFinal() {
    __asm {
        fst dword ptr [esi+2Ch]
        fcom qword ptr ds:[0x00D36880]
        pushfd
        pushad
        push esi
        call CaptureDistanceFinal
        popad
        popfd
        jmp dword ptr [g_ret_distance]
    }
}
__declspec(naked) void HookDistanceLive() {
    __asm {
        fstp dword ptr [edi+4Ch]
        mov ecx, [ebp-0Ch]
        pushfd
        pushad
        push edi
        call CaptureDistanceLive
        popad
        popfd
        jmp dword ptr [g_ret_distance_live]
    }
}

static std::string make_json() {
    char buf[4096];
    snprintf(buf,sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"distance_ok\": %s,\n"
        "  \"height_ok\": %s,\n"
        "  \"distance_live_ok\": %s,\n"
        "  \"distance\": %.6f,\n"
        "  \"height\": %.6f,\n"
        "  \"distance_live\": %.6f,\n"
        "  \"distance_base\": \"0x%08lX\",\n"
        "  \"height_base\": \"0x%08lX\",\n"
        "  \"distance_live_base\": \"0x%08lX\",\n"
        "  \"counts\": {\"distance\": %ld, \"height\": %ld, \"distance_live\": %ld},\n"
        "  \"hook\": \"height 0x0052D6C1, distance_final 0x005341EF, distance_live 0x0052DF5C\",\n"
        "  \"tick\": %lu\n"
        "}\n",
        g_distance_ok?"true":"false", g_height_ok?"true":"false", g_distance_live_ok?"true":"false",
        g_distance, g_height, g_distance_live, g_distance_base, g_height_base, g_distance_live_base,
        g_distance_count, g_height_count, g_distance_live_count, GetTickCount());
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID) {
    const unsigned char h_old[] = {0xD9,0x46,0x34,0xD9,0x5D,0xC8};
    const unsigned char d_old[] = {0xD9,0x56,0x2C,0xDC,0x15,0x80,0x68,0xD3,0x00};
    const unsigned char dl_old[] = {0xD9,0x5F,0x4C,0x8B,0x4D,0xF4};
    g_ret_height = pangya_va(0x0052D6C7);
    g_ret_distance = pangya_va(0x005341F8);
    g_ret_distance_live = pangya_va(0x0052DF62);
    if (pangya_install_jmp(0x0052D6C1,h_old,sizeof(h_old),HookHeight,sizeof(h_old),"pangya_distance_height_logger.log")) g_height_ok=1;
    if (pangya_install_jmp(0x005341EF,d_old,sizeof(d_old),HookDistanceFinal,sizeof(d_old),"pangya_distance_height_logger.log")) g_distance_ok=1;
    if (pangya_install_jmp(0x0052DF5C,dl_old,sizeof(dl_old),HookDistanceLive,sizeof(dl_old),"pangya_distance_height_logger.log")) g_distance_live_ok=1;
    pangya_append_log("pangya_distance_height_logger.log","loaded distance=%ld height=%ld live=%ld",g_distance_ok,g_height_ok,g_distance_live_ok);
    for(;;){ pangya_write_text_atomic("pangya_distance_height_live.json", make_json()); Sleep(150); }
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL);if(t)CloseHandle(t);} return TRUE; }
