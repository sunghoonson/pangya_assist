#include "pangya_plugin_common.h"

static volatile LONG g_hook_ok=0, g_count=0;
static DWORD g_ret=0;
static DWORD g_ball_ptr=0, g_hole_ptr=0, g_state_ptr=0, g_target_ptr=0;
static float g_ball_x=0, g_ball_z=0, g_hole_x=0, g_hole_z=0;
static float g_aim_x=0, g_aim_z=1;
static float g_distance_yards=0, g_height_diff=0;
static float g_current_line_raw=0, g_current_line_desvio=0, g_current_line_pb=0, g_current_line_board=0;
static float g_current_line_board_by_pb = 0.0f;

static const float INTERNAL_TO_YARD = 0.3125f;
static const float DESVIO_SCALE_PANGYA_TO_YARD = 0.3125f / 1.5f;
static const float YARDS_TO_PB_DEFAULT = 0.2167f;
static const float BOARD_PER_PB_DEFAULT = 0.2121f;

extern "C" __declspec(noinline) void __stdcall CapturePreShotCoords(DWORD ecx_value, DWORD eax_value){
    g_hole_ptr=ecx_value;
    g_ball_ptr=eax_value;
    pangya_read_value<float>(ecx_value+0x00,g_hole_x);
    pangya_read_value<float>(ecx_value+0x08,g_hole_z);
    pangya_read_value<float>(eax_value+0x14,g_ball_x);
    pangya_read_value<float>(eax_value+0x1C,g_ball_z);
    float dx=g_hole_x-g_ball_x, dz=g_hole_z-g_ball_z;
    g_distance_yards = sqrtf(dx*dx+dz*dz) * INTERNAL_TO_YARD;
    InterlockedIncrement((LONG*)&g_count);
}

static void PollAimAndCalculate(){
    // 원본 복원 메모: 기존 DLL은 state+0x13C의 조준 벡터를 polling했다.
    // state 포인터가 확인되지 않는 환경에서도 JSON 계약을 유지하기 위해,
    // 조준 벡터 미확인 시 ball->hole 방향을 기본값으로 사용한다.
    float hx=g_hole_x-g_ball_x, hz=g_hole_z-g_ball_z;
    float hlen=sqrtf(hx*hx+hz*hz);
    if(hlen <= 0.0001f) return;
    float hux=hx/hlen, huz=hz/hlen;

    DWORD state=0;
    // 자주 쓰인 클라 글로벌 후보. 버전 차이가 있으면 0으로 남는다.
    pangya_read_value<DWORD>(pangya_va(0x00E10FAC), state);
    g_state_ptr=state;
    if(state){
        DWORD target=0; pangya_read_value<DWORD>(state+0x13C,target); g_target_ptr=target;
        if(target){
            float ax=0,az=0;
            pangya_read_value<float>(target+0x00,ax);
            pangya_read_value<float>(target+0x08,az);
            float al=sqrtf(ax*ax+az*az);
            if(al>0.0001f){ g_aim_x=ax/al; g_aim_z=az/al; }
        }
    } else {
        g_aim_x=hux; g_aim_z=huz;
    }

    // 2D cross: aim line 기준 hole 위치의 signed lateral internal distance.
    // GUI에서 DIFF = current_line_pb * board_per_pb - target_board 로 쓴다.
    float lateral_internal = hx * g_aim_z - hz * g_aim_x;
    g_current_line_raw = lateral_internal * INTERNAL_TO_YARD;
    g_current_line_desvio = lateral_internal * DESVIO_SCALE_PANGYA_TO_YARD;
    g_current_line_pb = g_current_line_desvio / YARDS_TO_PB_DEFAULT;
    g_current_line_board_by_pb = g_current_line_pb * BOARD_PER_PB_DEFAULT;
}


__declspec(naked) void HookLine(){
    __asm{
        pushfd
        pushad
        push eax
        push ecx
        call CapturePreShotCoords
        popad
        popfd
        fld dword ptr [ecx]
        fsub dword ptr [eax+14h]
        fstp dword ptr [ebp-10h]
        jmp dword ptr [g_ret]
    }
}

static std::string make_json(){
    PollAimAndCalculate();
    double aim_angle=pangya_deg_norm360(pangya_rad_to_deg(atan2((double)g_aim_x,(double)g_aim_z)));
    float hx=g_hole_x-g_ball_x, hz=g_hole_z-g_ball_z; float hlen=sqrtf(hx*hx+hz*hz); float hux=0,huz=1; if(hlen>0.0001f){hux=hx/hlen;huz=hz/hlen;}
    double hole_angle=pangya_deg_norm360(pangya_rad_to_deg(atan2((double)hux,(double)huz)));
    char buf[8192];
    snprintf(buf,sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"line_ok\": %s,\n"
        "  \"source\": \"inline_hook_005340EC_state_poll\",\n"
        "  \"hook\": \"0x005340EC pre-shot coords + state+0x13C aim polling\",\n"
        "  \"hook_installed\": %s,\n"
        "  \"definition\": \"point_to_line_v3_gui_correct\",\n"
        "  \"tick\": %lu,\n"
        "  \"count\": %ld,\n"
        "  \"state\": \"0x%08lX\",\n"
        "  \"target_ptr\": \"0x%08lX\",\n"
        "  \"distance_yards\": %.6f,\n"
        "  \"height_diff\": %.6f,\n"
        "  \"ball\": {\"x\": %.6f, \"z\": %.6f},\n"
        "  \"hole\": {\"x\": %.6f, \"z\": %.6f},\n"
        "  \"aim_raw\": {\"x\": %.6f, \"z\": %.6f},\n"
        "  \"aim_unit\": {\"x\": %.9f, \"z\": %.9f},\n"
        "  \"hole_unit\": {\"x\": %.9f, \"z\": %.9f},\n"
        "  \"live_global\": \"0x%08lX\",\n"
        "  \"live_global_ok\": %s,\n"
        "  \"aim_angle_deg\": %.6f,\n"
        "  \"hole_angle_deg\": %.6f,\n"
        "  \"current_line_raw_lateral_yards\": %.9f,\n"
        "  \"current_line_desvio_yards\": %.9f,\n"
        "  \"current_line_pb\": %.9f,\n"
        "  \"current_line_board\": %.9f,\n"
        "  \"current_line_board_by_pb\": %.9f,\n"
        "  \"constants\": {\n"
        "    \"internal_to_yard\": %.9f,\n"
        "    \"desvio_scale_pangya_to_yard\": %.9f,\n"
        "    \"yards_to_pb_default\": %.9f,\n"
        "    \"board_per_pb_default\": %.9f\n"
        "  },\n"
        "  \"note\": \"GUI should compute DIFF = current_line_pb * gui_board_per_pb - target_board. Sign can be flipped in GUI if needed.\"\n"
        "}\n",
        g_count>0?"true":"false", g_hook_ok?"true":"false", GetTickCount(), g_count, g_state_ptr, g_target_ptr,
        g_distance_yards, g_height_diff, g_ball_x,g_ball_z,g_hole_x,g_hole_z, g_aim_x,g_aim_z,g_aim_x,g_aim_z,hux,huz,
        pangya_va(0x00E10FAC), g_state_ptr?"true":"false", aim_angle,hole_angle,
        g_current_line_raw,g_current_line_desvio,g_current_line_pb,g_current_line_board_by_pb,g_current_line_board_by_pb,
        INTERNAL_TO_YARD,DESVIO_SCALE_PANGYA_TO_YARD,YARDS_TO_PB_DEFAULT,BOARD_PER_PB_DEFAULT);
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID){
    const unsigned char old[]={0xD9,0x01,0xD8,0x60,0x14,0xD9,0x5D,0xF0};
    g_ret=pangya_va(0x005340F4);
    if(pangya_install_jmp(0x005340EC,old,sizeof(old),HookLine,sizeof(old),"pangya_lateral_offset_logger.log")) g_hook_ok=1;
    pangya_append_log("pangya_lateral_offset_logger.log","loaded hook=%ld",g_hook_ok);
    for(;;){ pangya_write_text_atomic("pangya_lateral_offset_live.json", make_json()); Sleep(120); }
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL);if(t)CloseHandle(t);} return TRUE; }
