@echo off
setlocal
cd /d "%~dp0"

echo ===== build pangya_club_logger =====
call "pangya_club_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_distance_height_logger =====
call "pangya_distance_height_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_ground_logger =====
call "pangya_ground_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_lateral_offset_logger =====
call "pangya_lateral_offset_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_plugin_loader =====
call "pangya_plugin_loader\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_slope_logger =====
call "pangya_slope_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_spin_curve_live_logger =====
call "pangya_spin_curve_live_logger\build.bat"
if errorlevel 1 exit /b 1

echo ===== build pangya_wind_logger =====
call "pangya_wind_logger\build.bat"
if errorlevel 1 exit /b 1

echo.
echo [OK] all plugin source builds completed.
