#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <cstdio>
#include <cstdint>
#include <cmath>
#include <string>
#include <sstream>
#include <fstream>

#ifndef PANGYA_IMAGE_BASE
#define PANGYA_IMAGE_BASE 0x00400000u
#endif

static inline DWORD pangya_exe_base() {
    return (DWORD)(uintptr_t)GetModuleHandleA(NULL);
}

static inline DWORD pangya_va(DWORD preferred_va) {
    return pangya_exe_base() + (preferred_va - PANGYA_IMAGE_BASE);
}

static inline std::string pangya_exe_dir() {
    char path[MAX_PATH] = {0};
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::string s(path);
    size_t p = s.find_last_of("\\/");
    if (p != std::string::npos) s.resize(p);
    return s;
}

static inline void pangya_ensure_logs_dir() {
    std::string dir = pangya_exe_dir() + "\\logs";
    CreateDirectoryA(dir.c_str(), NULL);
}

static inline std::string pangya_log_path(const char* filename) {
    pangya_ensure_logs_dir();
    return pangya_exe_dir() + "\\logs\\" + filename;
}

static inline void pangya_append_log(const char* filename, const char* fmt, ...) {
    char buf[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf_s(buf, sizeof(buf), _TRUNCATE, fmt, ap);
    va_end(ap);

    std::string path = pangya_log_path(filename);
    FILE* fp = nullptr;
    fopen_s(&fp, path.c_str(), "ab");
    if (!fp) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(fp, "[%04u-%02u-%02u %02u:%02u:%02u.%03u] %s\r\n",
        st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, buf);
    fclose(fp);
}

static inline bool pangya_write_text_atomic(const char* filename, const std::string& text) {
    std::string path = pangya_log_path(filename);
    std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp.c_str(), std::ios::binary | std::ios::trunc);
        if (!f.good()) return false;
        f.write(text.data(), (std::streamsize)text.size());
    }
    if (!MoveFileExA(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        DeleteFileA(tmp.c_str());
        return false;
    }
    return true;
}

static inline bool pangya_is_readable(const void* p, size_t n) {
    if (!p) return false;
    __try {
        volatile const unsigned char* q = (volatile const unsigned char*)p;
        volatile unsigned char a = q[0];
        volatile unsigned char b = q[n ? n - 1 : 0];
        (void)a; (void)b;
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

template<typename T>
static inline bool pangya_read_value(DWORD addr, T& out) {
    if (!addr || !pangya_is_readable((const void*)addr, sizeof(T))) return false;
    __try {
        out = *(const T*)addr;
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static inline bool pangya_install_jmp(DWORD preferred_va, const unsigned char* expected, size_t expected_len,
                                      void* hook_func, size_t stolen_len, const char* tag) {
    DWORD addr = pangya_va(preferred_va);
    if (stolen_len < 5) return false;
    if (!pangya_is_readable((const void*)addr, stolen_len)) {
        pangya_append_log(tag, "hook address unreadable preferred=0x%08lX runtime=0x%08lX", preferred_va, addr);
        return false;
    }
    if (expected && expected_len > 0) {
        if (memcmp((const void*)addr, expected, expected_len) != 0) {
            const unsigned char* cur = (const unsigned char*)addr;
            pangya_append_log(tag, "original bytes mismatch preferred=0x%08lX runtime=0x%08lX cur=%02X %02X %02X %02X %02X %02X %02X %02X",
                preferred_va, addr, cur[0], cur[1], cur[2], cur[3], cur[4], cur[5], cur[6], cur[7]);
            return false;
        }
    }
    DWORD old = 0;
    if (!VirtualProtect((void*)addr, stolen_len, PAGE_EXECUTE_READWRITE, &old)) {
        pangya_append_log(tag, "VirtualProtect failed preferred=0x%08lX err=%lu", preferred_va, GetLastError());
        return false;
    }
    unsigned char patch[32] = {0};
    patch[0] = 0xE9;
    *(int32_t*)(patch + 1) = (int32_t)((DWORD)(uintptr_t)hook_func - (addr + 5));
    for (size_t i = 5; i < stolen_len; ++i) patch[i] = 0x90;
    memcpy((void*)addr, patch, stolen_len);
    FlushInstructionCache(GetCurrentProcess(), (void*)addr, stolen_len);
    DWORD tmp = 0;
    VirtualProtect((void*)addr, stolen_len, old, &tmp);
    pangya_append_log(tag, "hook installed preferred=0x%08lX runtime=0x%08lX len=%u hook=0x%08lX", preferred_va, addr, (unsigned)stolen_len, (DWORD)(uintptr_t)hook_func);
    return true;
}

static inline double pangya_rad_to_deg(double r) { return r * 180.0 / 3.14159265358979323846; }
static inline double pangya_deg_norm360(double d) { while (d < 0.0) d += 360.0; while (d >= 360.0) d -= 360.0; return d; }
static inline double pangya_deg_signed180(double d) { d = pangya_deg_norm360(d); if (d > 180.0) d -= 360.0; return d; }
