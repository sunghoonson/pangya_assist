#include "pangya_plugin_common.h"

static volatile LONG g_hook_ok=0, g_count=0;
static DWORD g_ret=0;
static DWORD g_esi=0, g_hook_addr=0, g_call_target=0, g_return_addr=0;
static int g_ground=100;

extern "C" __declspec(noinline) void __stdcall CaptureGround(DWORD ground_value, DWORD esi_value) {
    g_esi = esi_value;
    int v = (int)ground_value;
    // 이 지점의 ECX는 UI 인자로 push된 지면 퍼센트 후보였다.
    if (v >= 0 && v <= 200) g_ground = v;
    InterlockedIncrement((LONG*)&g_count);
}

__declspec(naked) void HookGround() {
    __asm {
        pushfd
        pushad
        push esi
        mov eax, [esp+24h+4h]  // pushad/pushfd 이전 원래 [esp]
        push eax
        call CaptureGround
        popad
        popfd
        lea ecx, [esi+7Ch]
        call dword ptr [g_call_target]
        jmp dword ptr [g_ret]
    }
}

static std::string make_json(){
    char buf[2048];
    snprintf(buf,sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"ground_ok\": %s,\n"
        "  \"ground\": %d,\n"
        "  \"tick\": %lu,\n"
        "  \"count\": %ld,\n"
        "  \"hook_installed\": %s,\n"
        "  \"hook\": \"0x006E2408 ground percent UI argument logger\",\n"
        "  \"esi\": \"0x%08lX\",\n"
        "  \"hook_addr\": \"0x%08lX\",\n"
        "  \"call_target\": \"0x%08lX\",\n"
        "  \"return_addr\": \"0x%08lX\"\n"
        "}\n", g_count>0?"true":"false", g_ground, GetTickCount(), g_count,
        g_hook_ok?"true":"false", g_esi, g_hook_addr, g_call_target, g_return_addr);
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID){
    const unsigned char old[] = {0x8D,0x4E,0x7C,0xE8,0x70,0xA8,0xE5,0xFF};
    g_hook_addr=pangya_va(0x006E2408); g_call_target=pangya_va(0x0053CC80); g_return_addr=pangya_va(0x006E2410); g_ret=g_return_addr;
    if(pangya_install_jmp(0x006E2408,old,sizeof(old),HookGround,sizeof(old),"pangya_ground_logger.log")) g_hook_ok=1;
    pangya_append_log("pangya_ground_logger.log","loaded hook=%ld",g_hook_ok);
    for(;;){ pangya_write_text_atomic("pangya_ground_live.json", make_json()); Sleep(200); }
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL);if(t)CloseHandle(t);} return TRUE; }
