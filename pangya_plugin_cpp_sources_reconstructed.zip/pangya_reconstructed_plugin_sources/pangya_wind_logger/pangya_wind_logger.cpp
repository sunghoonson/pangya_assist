#include "pangya_plugin_common.h"

static volatile LONG g_hook_wind_ok = 0;
static volatile LONG g_hook_degree_ok = 0;
static volatile LONG g_seen = 0;
static volatile LONG g_write = 0;
static volatile DWORD g_wind_tick = 0;
static volatile DWORD g_degree_tick = 0;
static float g_wind = 0.0f;
static float g_radian = 0.0f;
static float g_signed_radian = 0.0f;
static DWORD g_wind_ret = 0;
static DWORD g_degree_ret = 0;

extern "C" __declspec(noinline) void __stdcall CaptureWindFromEbp(DWORD ebp_value) {
    float v = 0.0f;
    if (pangya_read_value<float>(ebp_value + 8, v)) {
        if (v >= 0.0f && v <= 30.0f) {
            g_wind = v;
            g_wind_tick = GetTickCount();
            InterlockedIncrement((LONG*)&g_seen);
        }
    }
}

extern "C" __declspec(noinline) void __stdcall CaptureDegreeFromEsp(DWORD esp_value) {
    float r = 0.0f;
    float sr = 0.0f;
    // 이 지점은 호출부/스택 상태에 따라 esp+4 또는 ebp+8 후보가 될 수 있었다.
    // 기존 live JSON 명칭을 유지하기 위해 esp+4를 우선 사용한다.
    if (pangya_read_value<float>(esp_value + 4, r)) {
        if (r > -100.0f && r < 100.0f) {
            g_radian = r;
            g_degree_tick = GetTickCount();
            InterlockedIncrement((LONG*)&g_seen);
        }
    }
    if (pangya_read_value<float>(esp_value + 8, sr)) {
        if (sr > -100.0f && sr < 100.0f) g_signed_radian = sr;
    }
}

__declspec(naked) void HookWind() {
    __asm {
        pushfd
        pushad
        push ebp
        call CaptureWindFromEbp
        popad
        popfd
        lea ecx, [ebp-44h]
        push ecx
        lea ebx, [esi+5Ch]
        jmp dword ptr [g_wind_ret]
    }
}

__declspec(naked) void HookDegree() {
    __asm {
        pushfd
        pushad
        mov eax, esp
        add eax, 24h
        push eax
        call CaptureDegreeFromEsp
        popad
        popfd
        lea edx, [ebp-44h]
        push edx
        lea edx, [ebp-74h]
        jmp dword ptr [g_degree_ret]
    }
}

static std::string make_json() {
    double degree = pangya_deg_norm360(pangya_rad_to_deg(g_radian));
    double signed_degree = pangya_deg_signed180(pangya_rad_to_deg(g_signed_radian != 0.0f ? g_signed_radian : g_radian));
    char buf[4096];
    snprintf(buf, sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"wind_ok\": %s,\n"
        "  \"degree_ok\": %s,\n"
        "  \"wind\": %.3f,\n"
        "  \"degree\": %.3f,\n"
        "  \"radian\": %.9f,\n"
        "  \"signed_degree\": %.3f,\n"
        "  \"signed_radian\": %.9f,\n"
        "  \"tick\": %lu,\n"
        "  \"wind_tick\": %lu,\n"
        "  \"degree_tick\": %lu,\n"
        "  \"seen_count\": %ld,\n"
        "  \"write_count\": %ld,\n"
        "  \"event\": \"wind_degree_0_360\",\n"
        "  \"wind_source\": \"matrix_4D54C0_ret_006C7566_caller_ebp_plus_8\",\n"
        "  \"degree_source\": \"matrix_4D54C0_ret_006C7632_arg_esp_plus_4\"\n"
        "}\n",
        g_hook_wind_ok ? "true" : "false", g_hook_degree_ok ? "true" : "false",
        g_wind, degree, g_radian, signed_degree, g_signed_radian,
        GetTickCount(), g_wind_tick, g_degree_tick, g_seen, g_write);
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID) {
    pangya_ensure_logs_dir();
    const unsigned char wind_old[]   = {0x8D,0x4D,0xBC,0x51,0x8D,0x5E,0x5C};
    const unsigned char degree_old[] = {0x8D,0x55,0xBC,0x52,0x8D,0x55,0x8C};
    g_wind_ret = pangya_va(0x006C756D);
    g_degree_ret = pangya_va(0x006C7639);
    if (pangya_install_jmp(0x006C7566, wind_old, sizeof(wind_old), HookWind, sizeof(wind_old), "pangya_wind_logger.log")) g_hook_wind_ok = 1;
    if (pangya_install_jmp(0x006C7632, degree_old, sizeof(degree_old), HookDegree, sizeof(degree_old), "pangya_wind_logger.log")) g_hook_degree_ok = 1;
    pangya_append_log("pangya_wind_logger.log", "pangya_wind_logger loaded wind=%ld degree=%ld", g_hook_wind_ok, g_hook_degree_ok);
    for (;;) {
        pangya_write_text_atomic("pangya_wind_live.json", make_json());
        InterlockedIncrement((LONG*)&g_write);
        Sleep(120);
    }
}

BOOL APIENTRY DllMain(HMODULE h, DWORD r, LPVOID) {
    if (r == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        HANDLE t = CreateThread(NULL, 0, Worker, NULL, 0, NULL);
        if (t) CloseHandle(t);
    }
    return TRUE;
}
