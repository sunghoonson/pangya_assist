#include "pangya_plugin_common.h"

static volatile LONG g_hook_ok=0, g_hits=0;
static DWORD g_ret=0;
static DWORD g_manager=0, g_entry=0, g_name_ptr=0;
static int g_type=-1;

static const char* club_code_from_type(int t){
    switch(t){
    case 0: return "_1W"; case 1: return "_2W"; case 2: return "_3W";
    case 3: return "_2I"; case 4: return "_3I"; case 5: return "_4I"; case 6: return "_5I";
    case 7: return "_6I"; case 8: return "_7I"; case 9: return "_8I"; case 10: return "_9I";
    case 11: return "PW"; case 12: return "SW"; case 13: return "PT1"; case 14: return "PT2";
    default: return "UNKNOWN";
    }
}
static const char* club_name_from_type(int t){
    const char* c=club_code_from_type(t); return c;
}

extern "C" __declspec(noinline) void __stdcall CaptureClubManager(DWORD ecx_value){
    g_manager=ecx_value;
    InterlockedIncrement((LONG*)&g_hits);
}

__declspec(naked) void HookClubSelect(){
    __asm{
        pushfd
        pushad
        push ecx
        call CaptureClubManager
        popad
        popfd
        push ebp
        mov ebp, esp
        mov eax, [ebp+08h]
        jmp dword ptr [g_ret]
    }
}

static void PollClub(){
    DWORD entry=0; int mt=-1, et=-1;
    if(g_manager && pangya_read_value<DWORD>(g_manager+0x04, entry)){
        g_entry=entry;
        pangya_read_value<int>(g_manager+0x28, mt);
        unsigned char b=0;
        if(entry && pangya_read_value<unsigned char>(entry+0x21,b)) et=(int)b;
        g_type = (et>=0 ? et : mt);
        DWORD np=0; if(entry) pangya_read_value<DWORD>(entry+0x04, np); g_name_ptr=np;
    }
}

static std::string make_json(){
    PollClub();
    const char* club=club_code_from_type(g_type);
    char buf[4096];
    snprintf(buf,sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"club_ok\": %s,\n"
        "  \"club\": \"%s\",\n"
        "  \"club_name\": \"%s\",\n"
        "  \"club_long_name\": \"%s\",\n"
        "  \"club_index\": %d,\n"
        "  \"source\": \"select_hook_and_manager_polling\",\n"
        "  \"tick\": %lu,\n"
        "  \"hook_installed\": %s,\n"
        "  \"hook\": \"0x006AC9A0 setup hook + manager polling\",\n"
        "  \"hook_hits\": %ld,\n"
        "  \"manager\": \"0x%08lX\",\n"
        "  \"name_ptr\": \"0x%08lX\",\n"
        "  \"current_entry\": \"0x%08lX\",\n"
        "  \"manager_offset_current_entry\": \"manager+0x04\",\n"
        "  \"manager_offset_type\": \"manager+0x28\",\n"
        "  \"entry_offset_type\": \"current_entry+0x21\"\n"
        "}\n", (g_type>=0)?"true":"false", club, club, club, g_type, GetTickCount(),
        g_hook_ok?"true":"false", g_hits, g_manager, g_name_ptr, g_entry);
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID){
    const unsigned char old[]={0x55,0x8B,0xEC,0x8B,0x45,0x08};
    g_ret=pangya_va(0x006AC9A6);
    if(pangya_install_jmp(0x006AC9A0,old,sizeof(old),HookClubSelect,sizeof(old),"pangya_club_logger.log")) g_hook_ok=1;
    pangya_append_log("pangya_club_logger.log","select-by-name hook %s",g_hook_ok?"installed":"failed");
    for(;;){ pangya_write_text_atomic("pangya_club_live.json", make_json()); Sleep(200); }
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL);if(t)CloseHandle(t);} return TRUE; }
