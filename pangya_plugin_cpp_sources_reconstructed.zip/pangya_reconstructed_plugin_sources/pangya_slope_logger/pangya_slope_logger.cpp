#include "pangya_plugin_common.h"

static volatile LONG g_x_ok = 0, g_y_ok = 0, g_ret_ok = 0;
static volatile LONG g_x_count = 0, g_y_count = 0, g_ret_count = 0;
static volatile LONG g_seq = 0;
static DWORD g_ret_x = 0, g_ret_y = 0, g_ret_return = 0;
static DWORD g_ebx = 0, g_esi_result = 0, g_original_esp = 0, g_source_va = 0;
static float g_nx = 0, g_ny = 1, g_nz = 0;
static float g_m[12] = {0};

extern "C" __declspec(noinline) void __stdcall CaptureSlopeRaw(DWORD ebx_value) {
    g_ebx = ebx_value;
    float x=0,y=1,z=0;
    pangya_read_value<float>(ebx_value + 0x1C, x);
    pangya_read_value<float>(ebx_value + 0x20, y);
    pangya_read_value<float>(ebx_value + 0x24, z);
    g_nx = x; g_ny = y; g_nz = z;
    g_source_va = pangya_va(0x006E1DFC);
    InterlockedIncrement((LONG*)&g_x_count);
}

extern "C" __declspec(noinline) void __stdcall CaptureSlopeRawY(DWORD ebx_value) {
    float y=1,z=0;
    pangya_read_value<float>(ebx_value + 0x20, y);
    pangya_read_value<float>(ebx_value + 0x24, z);
    g_ny = y; g_nz = z;
    g_source_va = pangya_va(0x006E1E0C);
    InterlockedIncrement((LONG*)&g_y_count);
}

extern "C" __declspec(noinline) void __stdcall CaptureSlopeReturn(DWORD esi_value, DWORD esp_value) {
    g_esi_result = esi_value;
    g_original_esp = esp_value;
    for (int i=0;i<12;i++) pangya_read_value<float>(esi_value + i*4, g_m[i]);
    g_source_va = pangya_va(0x006E1F68);
    InterlockedIncrement((LONG*)&g_ret_count);
    InterlockedIncrement((LONG*)&g_seq);
}

__declspec(naked) void HookX() {
    __asm {
        pushfd
        pushad
        push ebx
        call CaptureSlopeRaw
        popad
        popfd
        mov eax, [ebx+1Ch]
        push esi
        mov esi, [ebp+08h]
        jmp dword ptr [g_ret_x]
    }
}

__declspec(naked) void HookY() {
    __asm {
        pushfd
        pushad
        push ebx
        call CaptureSlopeRawY
        popad
        popfd
        mov edx, [ebx+24h]
        mov [esi+14h], edx
        jmp dword ptr [g_ret_y]
    }
}

__declspec(naked) void HookReturn() {
    __asm {
        pushfd
        pushad
        mov eax, esp
        add eax, 24h
        push eax
        push esi
        call CaptureSlopeReturn
        popad
        popfd
        mov eax, esi
        pop esi
        pop ebx
        mov esp, ebp
        pop ebp
        jmp dword ptr [g_ret_return]
    }
}

static std::string make_json() {
    float mag = sqrtf(g_nx*g_nx + g_nz*g_nz);
    float minv = 999.0f; int minoff = 0;
    for (int i=0;i<12;i++) { float a=fabsf(g_m[i]); if (a>0.0f && a<minv) {minv=a; minoff=i*4;} }
    char buf[8192];
    snprintf(buf, sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"reason\": \"slope raw normal + return result matrix captured\",\n"
        "  \"hook\": \"0x006E1DFC/0x006E1E0C raw + 0x006E1F68 return result logger\",\n"
        "  \"hook_x_installed\": %s,\n"
        "  \"hook_y_installed\": %s,\n"
        "  \"hook_return_installed\": %s,\n"
        "  \"seq\": %ld,\n"
        "  \"tick\": %lu,\n"
        "  \"source\": \"return_006E1F68\",\n"
        "  \"source_va\": \"0x%08lX\",\n"
        "  \"counts\": {\"x_read\": %ld, \"y_read\": %ld, \"return\": %ld},\n"
        "  \"pointers\": {\"ebx_base\": \"0x%08lX\", \"esi_result\": \"0x%08lX\", \"original_esp\": \"0x%08lX\"},\n"
        "  \"slope_normal\": {\"x\": %.10f, \"up_y\": %.10f, \"z\": %.10f, \"xz_mag\": %.10f},\n"
        "  \"simple_break_candidates\": {\"x_pos\": %.6f, \"x_neg\": %.6f, \"z_pos\": %.6f, \"z_neg\": %.6f, \"mag_pos\": %.6f, \"mag_neg\": %.6f},\n"
        "  \"result_matrix\": {\n"
        "    \"r00\": %.10f, \"r04\": %.10f, \"r08\": %.10f,\n"
        "    \"r0c\": %.10f, \"r10\": %.10f, \"r14\": %.10f,\n"
        "    \"r18\": %.10f, \"r1c\": %.10f, \"r20\": %.10f,\n"
        "    \"r24\": %.10f, \"r28\": %.10f, \"r2c\": %.10f\n"
        "  },\n"
        "  \"result_div_00875_candidates\": {\n"
        "    \"r00\": %.6f, \"r04\": %.6f, \"r08\": %.6f,\n"
        "    \"r0c\": %.6f, \"r10\": %.6f, \"r14\": %.6f,\n"
        "    \"r18\": %.6f, \"r1c\": %.6f, \"r20\": %.6f,\n"
        "    \"r24\": %.6f, \"r28\": %.6f, \"r2c\": %.6f\n"
        "  },\n"
        "  \"result_direct_hint\": {\"min_abs_nonzero_value\": %.10f, \"offset\": \"0x%02X\"},\n"
        "  \"conversion_note\": \"Raw normal x/z use raw/0.00875. Return result matrix fields are logged both direct and /0.00875 because this is the function-after-rotation validation stage. PB/board are calculated after physics.\",\n"
        "  \"ring_overwrite\": 0\n"
        "}\n",
        g_x_ok?"true":"false", g_y_ok?"true":"false", g_ret_ok?"true":"false",
        g_seq, GetTickCount(), g_source_va, g_x_count, g_y_count, g_ret_count,
        g_ebx, g_esi_result, g_original_esp,
        g_nx, g_ny, g_nz, mag,
        g_nx/0.00875f, -g_nx/0.00875f, g_nz/0.00875f, -g_nz/0.00875f, mag/0.00875f, -mag/0.00875f,
        g_m[0],g_m[1],g_m[2],g_m[3],g_m[4],g_m[5],g_m[6],g_m[7],g_m[8],g_m[9],g_m[10],g_m[11],
        g_m[0]/0.00875f,g_m[1]/0.00875f,g_m[2]/0.00875f,g_m[3]/0.00875f,g_m[4]/0.00875f,g_m[5]/0.00875f,g_m[6]/0.00875f,g_m[7]/0.00875f,g_m[8]/0.00875f,g_m[9]/0.00875f,g_m[10]/0.00875f,g_m[11]/0.00875f,
        minv, minoff);
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID) {
    const unsigned char x_old[] = {0x8B,0x43,0x1C,0x56,0x8B,0x75,0x08};
    const unsigned char y_old[] = {0x8B,0x53,0x24,0x89,0x56,0x14};
    const unsigned char r_old[] = {0x8B,0xC6,0x5E,0x5B,0x8B,0xE5,0x5D};
    g_ret_x = pangya_va(0x006E1E03);
    g_ret_y = pangya_va(0x006E1E12);
    g_ret_return = pangya_va(0x006E1F6F);
    if (pangya_install_jmp(0x006E1DFC, x_old, sizeof(x_old), HookX, sizeof(x_old), "pangya_slope_logger.log")) g_x_ok=1;
    if (pangya_install_jmp(0x006E1E0C, y_old, sizeof(y_old), HookY, sizeof(y_old), "pangya_slope_logger.log")) g_y_ok=1;
    if (pangya_install_jmp(0x006E1F68, r_old, sizeof(r_old), HookReturn, sizeof(r_old), "pangya_slope_logger.log")) g_ret_ok=1;
    pangya_append_log("pangya_slope_logger.log", "pangya_slope_result_matrix_return_logger loaded. x=%ld y=%ld ret=%ld", g_x_ok, g_y_ok, g_ret_ok);
    for (;;) { pangya_write_text_atomic("pangya_slope_live.json", make_json()); Sleep(120); }
}

BOOL APIENTRY DllMain(HMODULE h, DWORD r, LPVOID) {
    if (r == DLL_PROCESS_ATTACH) { DisableThreadLibraryCalls(h); HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL); if(t)CloseHandle(t); }
    return TRUE;
}
