@echo off
setlocal
cd /d "%~dp0"

REM Must run from "x86 Native Tools Command Prompt for VS" or "Developer Command Prompt" with x86 cl available.
REM Output DLL is copied to .\dist\pangya_slope_logger.dll

if not exist dist mkdir dist
cl /nologo /O2 /MT /EHsc /LD /I "..\common" "pangya_slope_logger.cpp" /Fe:"dist\pangya_slope_logger.dll" user32.lib kernel32.lib
if errorlevel 1 (
    echo [ERROR] build failed: pangya_slope_logger
    exit /b 1
)
echo [OK] dist\pangya_slope_logger.dll
