#include "pangya_plugin_common.h"

static volatile LONG g_hook_ok=0, g_count=0, g_seq=0;
static DWORD g_ret=0, g_base=0, g_last_base=0;
static float g_curve=0.0f, g_spin=0.0f, g_curve_max=0.0f, g_spin_max=0.0f;

extern "C" __declspec(noinline) void __stdcall CaptureSpinCurve(DWORD esi_value){
    g_last_base=g_base; g_base=esi_value;
    pangya_read_value<float>(esi_value+0x18,g_curve);
    pangya_read_value<float>(esi_value+0x1C,g_spin);
    pangya_read_value<float>(esi_value+0x20,g_curve_max);
    pangya_read_value<float>(esi_value+0x24,g_spin_max);
    InterlockedIncrement((LONG*)&g_count);
    InterlockedIncrement((LONG*)&g_seq);
}

__declspec(naked) void HookSpinCurve(){
    __asm{
        fstp dword ptr [esi+18h]
        fld dword ptr [ebp-58h]
        fstp dword ptr [esi+1Ch]
        pushfd
        pushad
        push esi
        call CaptureSpinCurve
        popad
        popfd
        jmp dword ptr [g_ret]
    }
}

static std::string make_json(){
    char buf[4096];
    snprintf(buf,sizeof(buf),
        "{\n"
        "  \"ok\": true,\n"
        "  \"spin_ok\": %s,\n"
        "  \"curve_ok\": %s,\n"
        "  \"curve\": %.6f,\n"
        "  \"spin\": %.6f,\n"
        "  \"curve_max\": %.6f,\n"
        "  \"spin_max\": %.6f,\n"
        "  \"source\": \"inline_hook_final_00796886_esi\",\n"
        "  \"event\": \"hook_live\",\n"
        "  \"tick\": %lu,\n"
        "  \"seq\": %ld,\n"
        "  \"count\": %ld,\n"
        "  \"struct_base\": \"0x%08lX\",\n"
        "  \"curve_addr\": \"0x%08lX\",\n"
        "  \"spin_addr\": \"0x%08lX\",\n"
        "  \"curve_max_addr\": \"0x%08lX\",\n"
        "  \"spin_max_addr\": \"0x%08lX\",\n"
        "  \"offset_curve\": \"+0x18\",\n"
        "  \"offset_spin\": \"+0x1C\",\n"
        "  \"offset_curve_max\": \"+0x20\",\n"
        "  \"offset_spin_max\": \"+0x24\",\n"
        "  \"candidate\": \"r1311_0x00796886_esi_s89.0_curve_spin_x87_fstp\",\n"
        "  \"hook_va\": \"0x00796886\",\n"
        "  \"hook_installed\": %s,\n"
        "  \"hook\": \"single inline hook, no debug attach, no HWBP, no scan\"\n"
        "}\n",
        g_count>0?"true":"false", g_count>0?"true":"false", g_curve,g_spin,g_curve_max,g_spin_max,
        GetTickCount(), g_seq, g_count, g_base, g_base+0x18, g_base+0x1C, g_base+0x20, g_base+0x24,
        g_hook_ok?"true":"false");
    return std::string(buf);
}

DWORD WINAPI Worker(LPVOID){
    const unsigned char old[]={0xD9,0x5E,0x18,0xD9,0x45,0xA8,0xD9,0x5E,0x1C};
    g_ret=pangya_va(0x0079688F);
    if(pangya_install_jmp(0x00796886,old,sizeof(old),HookSpinCurve,sizeof(old),"pangya_spin_curve_live_hook_final.log")) g_hook_ok=1;
    pangya_append_log("pangya_spin_curve_live_hook_final.log","pangya_spin_curve_live_logger_hook_final loaded hook=%ld json=%s",g_hook_ok,pangya_log_path("pangya_spin_curve_live.json").c_str());
    for(;;){ pangya_write_text_atomic("pangya_spin_curve_live.json", make_json()); Sleep(120); }
}
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(NULL,0,Worker,NULL,0,NULL);if(t)CloseHandle(t);} return TRUE; }
